var searchData=
[
  ['rawdata',['RawData',['../namespacetemoto__resource__registrar.xhtml#a069d1959dc3e06e874692ce3bc78c36e',1,'temoto_resource_registrar']]],
  ['rrcatalogptr',['RrCatalogPtr',['../namespacetemoto__resource__registrar.xhtml#a34e8ce993149a27aafbb33bc24310b85',1,'temoto_resource_registrar']]],
  ['rrname',['RrName',['../namespacetemoto__resource__registrar.xhtml#a4978ed432aa4e0611c79698d7b9ff88b',1,'temoto_resource_registrar']]]
];
