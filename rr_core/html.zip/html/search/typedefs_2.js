var searchData=
[
  ['servername',['ServerName',['../namespacetemoto__resource__registrar.xhtml#a9d5a938988ae312c219fe1e8dbe7a510',1,'temoto_resource_registrar']]]
];
