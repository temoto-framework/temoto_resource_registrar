var searchData=
[
  ['load_5fcallback_5fptr_5f',['load_callback_ptr_',['../classtemoto__resource__registrar_1_1RrServerBase.xhtml#ac3702deb0f37fd2fbacb23c3023e3d0a',1,'temoto_resource_registrar::RrServerBase']]]
];
