var searchData=
[
  ['unload_5fcallback_5fptr_5f',['unload_callback_ptr_',['../classtemoto__resource__registrar_1_1RrServerBase.xhtml#a4cedcdc5a9ac8f5cd9ec12ba8e32f58e',1,'temoto_resource_registrar::RrServerBase']]]
];
