var searchData=
[
  ['get_5fname',['GET_NAME',['../temoto__logging_8h.xhtml#af8bca12527bac4b474e2ccb5acd8691e',1,'temoto_logging.h']]],
  ['get_5fname_5fff',['GET_NAME_FF',['../temoto__logging_8h.xhtml#afc8f055881056cb59fa97c532afa8f1d',1,'temoto_logging.h']]]
];
