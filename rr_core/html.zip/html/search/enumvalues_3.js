var searchData=
[
  ['update',['UPDATE',['../structtemoto__resource__registrar_1_1Status.xhtml#a65a5b5e34bd28a0d56d83f3dc89adaaba15a8022d0ed9cd9c2a2e756822703eb4',1,'temoto_resource_registrar::Status']]]
];
