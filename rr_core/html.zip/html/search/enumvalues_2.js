var searchData=
[
  ['ok',['OK',['../structtemoto__resource__registrar_1_1Status.xhtml#a65a5b5e34bd28a0d56d83f3dc89adaabae0aa021e21dddbd6d8cecec71e9cf564',1,'temoto_resource_registrar::Status']]]
];
