var searchData=
[
  ['resource_5fregistrar',['resource_registrar',['../namespaceresource__registrar.xhtml',1,'']]]
];
